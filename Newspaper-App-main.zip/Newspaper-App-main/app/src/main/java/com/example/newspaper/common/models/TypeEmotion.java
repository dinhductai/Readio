package com.example.newspaper.common.models;

public enum TypeEmotion {
    LIKE,
    HEARTFELT,
    UNIQUE,
    CREATIVE
}
